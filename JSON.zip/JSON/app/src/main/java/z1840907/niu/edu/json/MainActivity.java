/*****************************************************************************************
 CSCI 522 - Portfolio 16- Semester (Spring) Year - 2019

 Programmer(s): Manoj veluru
 Section: 1
 TA: Harshith Desamsetti

 Purpose: Design a simple application that will access JSON data from a webpage and display it in a ListView.

 ***************************************************************************************/
package z1840907.niu.edu.json;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity
{
    private List<State> stateList = new ArrayList<>();
    private StateArrayAdapter stateArrayAdapter;
    private ListView stateLV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        stateLV = findViewById(R.id.stateListView);
        stateArrayAdapter = new StateArrayAdapter(this, stateList);

        //Associate the adapter with ListView
        stateLV.setAdapter(stateArrayAdapter);
    }//end onCreate

    public void getData(View view)
    {
        String urlString = getString(R.string.web_url);

        try
        {
            URL url = new URL(urlString);

            //Create the ASyncTask
            StateTask stateTask = new StateTask();

            //Start AsyncTask
            stateTask.execute(url);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }//end getData

    //Method to convert JSON into an arrayList
    private void convertJSONtoArrayList(JSONObject states) {
        //Clear the List
        stateList.clear();

        try
        {
            JSONArray list = states.getJSONArray("places");

            //Loop to parse the JSON array into individual states
            for (int sub = 0; sub < list.length(); sub++)
            {
                //Retrieve a single object from the array
                JSONObject stateObj = list.getJSONObject(sub);

                //Add JSON Object to the list
                stateList.add( new State( stateObj.getString("Place"), stateObj.getInt("Number") ) );

            }//end for loop
        }
        catch (JSONException jse)
        {
            jse.printStackTrace();
        }
    }//end convertJSONtoArrayList

    //Inner AsyncTask class
    private class StateTask extends AsyncTask<URL, String, JSONObject>
    {
        @Override
        protected JSONObject doInBackground(URL... urls)
        {
            HttpURLConnection connection = null;

            try
            {
                //try to connect to the specified url
                connection = (HttpURLConnection)urls[0].openConnection();

                //Check if the connection was successful or not
                int responseCode = connection.getResponseCode();

                if(responseCode == HttpURLConnection.HTTP_OK)
                {
                    //Read the information from the webpage - line by line
                    StringBuilder builder = new StringBuilder();
                    try
                    {
                        BufferedReader reader = new BufferedReader( new InputStreamReader(connection.getInputStream()));

                        String line;
                        while ( (line = reader.readLine()) != null )
                        {
                            builder.append(line);
                        }
                    }
                    catch (IOException ioe)
                    {
                        publishProgress("Connection Error: input");
                        ioe.printStackTrace();
                    }

                    //Create and return the JSONObject
                    return new JSONObject(builder.toString());
                }
                else
                {
                    publishProgress("Connection Error: bad URL");
                }
            }
            catch (Exception e)
            {
                publishProgress("Connection Error: bad URL 2");
                e.printStackTrace();
            }
            finally {
                connection.disconnect();
            }
            return null;
        }//end doInBackground

        @Override
        protected void onProgressUpdate(String... values)
        {
            Toast.makeText(MainActivity.this, values[0], Toast.LENGTH_SHORT).show();

        }

        @Override
        protected void onPostExecute(JSONObject jsonObject)
        {
            convertJSONtoArrayList( jsonObject );

            //Set up the ArrayAdapter
            stateArrayAdapter.notifyDataSetChanged();

            //Start at the beginning of the ListView
            stateLV.smoothScrollToPosition(0);

        }//end onProgressExecute
    }//end StateTask class
}//end MainActivity
