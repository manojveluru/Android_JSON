/*****************************************************************************************
 CSCI 522 - Portfolio 16- Semester (Spring) Year - 2019

 Programmer(s): Manoj veluru
 Section: 1
 TA: Harshith Desamsetti

 Purpose: Design a simple application that will access JSON data from a webpage and display it in a ListView.

 ***************************************************************************************/
package z1840907.niu.edu.json;

public class State
{
    public final String stateAbbr;
    public final int stateNum;

    public State(String initAbbr, int initNum)
    {
        stateAbbr = initAbbr;
        stateNum = initNum;
    }//end constructor
}//end State Class
